<?php
$name = $_POST['user_name'];
$email = $_POST['user_email'];
$phone = $_POST['user_phone'];

echo "скрипт сработал! <br>". $name. "<br>".  $email. "<br>". $phone;

?>